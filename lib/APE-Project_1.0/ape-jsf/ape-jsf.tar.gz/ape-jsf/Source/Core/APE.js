var APE = {
	'version': '1.0',
	'Request': {},
	'Transport': {}
};
